module.exports = (sequelize, DataTypes) => {

    let cols = {
       
    };

    let config = {
       
    };

    const Categoria = sequelize.define("Categoria", cols, config);

  

    return Categoria;

}